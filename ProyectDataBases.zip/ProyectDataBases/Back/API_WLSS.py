
from SQL_DataBase import importTable
from SQL_DataBase import TablaEuropa
from SQL_DataBase import urlteam
from flask import Flask
from flask_cors import CORS


app = Flask(__name__)
CORS(app)


@app.route('/<league>/<year>')
def index(league,year):
    tabla=importTable(league,year)
    list = [{"club": x[0], "pj": x[1], "g": x[2], "e": x[3], "p": x[4], "gf": x[5], "gc": x[6], "dg": x[7], "Pts": x[8],"img":urlteam(x[0])} for x in tabla]
    return {"data":list}

@app.route('/<year>')
def index2(year):
    tabla=TablaEuropa(year)
    list = [{"club": x[0], "pg": x[1],"img":urlteam(x[0])} for x in tabla]
    return {"data":list}

if __name__ == "__main__":
    app.run(debug=True)
