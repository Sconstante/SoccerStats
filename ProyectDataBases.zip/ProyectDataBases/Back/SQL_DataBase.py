import numpy as np
import pyodbc
import csv


def importTable(league, season):

    def trans(matriz):
        hileras = len(matriz)
        columnas = len(matriz[0])
        t = [[0 for x in range(hileras)] for y in range(columnas)]

        for i in range(hileras):
            for j in range(columnas):
                t[j][i] = matriz[i][j]
        return t

    server = 'LAPTOP-HKUCUUQP\SQLEXPRESS'
    bd = 'SoccerStats'
    usuario = 'sa'
    contrasena = '214028'

    try:
        conexion = pyodbc.connect(
            'DRIVER={SQL server}; SERVER='+server+';DATABASE='+bd+';UID='+usuario+';PWD='+contrasena)
        #print('conexion exitosa')
    except:
        print('error al intentar conectarse')

    cursor = conexion.cursor()
    cursor.execute("select * from SoccerStatsPlus ss where ss.Season='" +
                   season+".0' and ss.League='"+league + "'")

    tabla = cursor.fetchone()
    DatosSueltos = []
    i = 0
    while i < 1000 and tabla != None:
        DatosSueltos.append(tabla)
        tabla = cursor.fetchone()
        i += 1

    cursor.execute("select [Home Team] from SoccerStatsPlus ss where ss.Season='" +
                   season+".0' and ss.League='"+league + "' group by [Home Team]")

    tabla = cursor.fetchone()
    TablaPos = []
    i = 0
    while i < 1000 and tabla != None:
        TablaPos.append(tabla[0])
        tabla = cursor.fetchone()
        i += 1

    cursor.close()
    conexion.close()
    TablaPosiciones = []
    TablaPosiciones.append(TablaPos)
    for i in range(8):
        TablaPosiciones.append(np.zeros(len(TablaPosiciones[0])).tolist())

    for i in range(len(TablaPosiciones[0])):
        for j in DatosSueltos:
            if(j[3] == TablaPosiciones[0][i] or j[4] == TablaPosiciones[0][i]):
                TablaPosiciones[1][i] += 1

            if((j[3] == TablaPosiciones[0][i] and (j[5] > j[6])) or (j[4] == TablaPosiciones[0][i] and (j[6] > j[5]))):
                TablaPosiciones[2][i] += 1

            if(j[5] == j[6] and (j[3] == TablaPosiciones[0][i] or j[4] == TablaPosiciones[0][i])):
                TablaPosiciones[3][i] += 1

            if((j[3] == TablaPosiciones[0][i] and (j[5] < j[6])) or (j[4] == TablaPosiciones[0][i] and (j[6] < j[5]))):
                TablaPosiciones[4][i] += 1

            if((j[3] == TablaPosiciones[0][i])):
                TablaPosiciones[5][i] += int(j[5])
                TablaPosiciones[6][i] += int(j[6])

            if((j[4] == TablaPosiciones[0][i])):
                TablaPosiciones[5][i] += int(j[6])
                TablaPosiciones[6][i] += int(j[5])

    for i in range(len(TablaPosiciones[0])):
        TablaPosiciones[7][i] = TablaPosiciones[5][i]-TablaPosiciones[6][i]
        TablaPosiciones[8][i] = TablaPosiciones[2][i]*3+TablaPosiciones[3][i]

    for i in range(len(TablaPosiciones[8])):
        for indice_actual in range(len(TablaPosiciones[8]) - 1):
            indice_siguiente_elemento = indice_actual + 1
            if TablaPosiciones[8][indice_actual] < TablaPosiciones[8][indice_siguiente_elemento]:
                # ... intercambiamos los elementos
                for i in range(len(TablaPosiciones)):
                    TablaPosiciones[i][indice_siguiente_elemento], TablaPosiciones[i][
                        indice_actual] = TablaPosiciones[i][indice_actual], TablaPosiciones[i][indice_siguiente_elemento]

    return trans(TablaPosiciones)

# ////////////////////////////////////


def TablaPromGol(TablaPosiciones):
    def trans(matriz):
        hileras = len(matriz)
        columnas = len(matriz[0])
        t = [[0 for x in range(hileras)] for y in range(columnas)]

        for i in range(hileras):
            for j in range(columnas):
                t[j][i] = matriz[i][j]
        return t

    TablaPosiciones = trans(TablaPosiciones)

    for i in range(len(TablaPosiciones[8])):
        for indice_actual in range(len(TablaPosiciones[8]) - 1):
            indice_siguiente_elemento = indice_actual + 1
            if (float(TablaPosiciones[5][indice_actual])/float(TablaPosiciones[1][indice_actual])) < (float(TablaPosiciones[5][indice_siguiente_elemento])/float(TablaPosiciones[1][indice_siguiente_elemento])):
                # ... intercambiamos los elementos
                for i in range(len(TablaPosiciones)):
                    TablaPosiciones[i][indice_siguiente_elemento], TablaPosiciones[i][
                        indice_actual] = TablaPosiciones[i][indice_actual], TablaPosiciones[i][indice_siguiente_elemento]
    
    TablaPosiciones = trans(TablaPosiciones)

    TablaGolP = []
    aux1 = []

    for i in range(10):
        aux1 = (TablaPosiciones[i][0], (float(
            TablaPosiciones[i][5]))/(float(TablaPosiciones[i][1])))
        TablaGolP.append(aux1)

    return TablaGolP


def TablaEuropa(season):
    server = 'LAPTOP-HKUCUUQP\SQLEXPRESS'
    bd = 'SoccerStats'
    usuario = 'sa'
    contrasena = '214028'

    try:
        conexion = pyodbc.connect(
            'DRIVER={SQL server}; SERVER='+server+';DATABASE='+bd+';UID='+usuario+';PWD='+contrasena)
        #print('conexion exitosa')
    except:
        print('error al intentar conectarse')

    cursor = conexion.cursor()
    cursor.execute("select League from dbo.Leagues l where l.League = 'Eng1' or  l.League = 'Spa1' or  l.League = 'Ger1' or  l.League = 'Fra1' or  l.League = 'Por1' or  l.League = 'Ita1' order by League")

    tabla = cursor.fetchone()
    LigasEuropa = []
    i = 0
    while i < 1000 and tabla != None:
        LigasEuropa.append(tabla[0])
        tabla = cursor.fetchone()
        i += 1

    cursor.close()
    conexion.close()

    TablasEuro = []

    contador = 0
    for i in range(len(LigasEuropa)):
        if (len(importTable(LigasEuropa[i], season)) != 0):
            #print('no hay liga')
            aux = importTable(LigasEuropa[i], season)

            if contador == 0:
                TablasEuro = aux
            else:
                #print('si hay liga')
                TablasEuro = np.concatenate((TablasEuro, aux))
            contador += 1

    return TablaPromGol(TablasEuro)


def urlteam(equipo):
    with open('Back/EquiposPlus.csv', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')

        url = ""
        for row in spamreader:
            if equipo == row[0]:
                url = row[2]

    return url


def Comparacion(equipo, year):
    server = 'LAPTOP-HKUCUUQP\SQLEXPRESS'
    bd = 'SoccerStats'
    usuario = 'sa'
    contrasena = '214028'

    try:
        conexion = pyodbc.connect(
            'DRIVER={SQL server}; SERVER='+server+';DATABASE='+bd+';UID='+usuario+';PWD='+contrasena)
        #print('conexion exitosa')
    except:
        print('error al intentar conectarse')

    cursor = conexion.cursor()
    cursor.execute("with ligas(equipo, liga) as (select s.[Home Team] ,s.League from dbo.SoccerStatsPlus s where s.[Home Team]='" +
                   equipo+"' and s.Season ='"+year+".0' group by s.[Home Team], s.League) select l.liga from ligas l")

    tabla = cursor.fetchone()
    DatosSueltos = []
    i = 0
    while i < 1000 and tabla != None:
        DatosSueltos.append(tabla[0])
        tabla = cursor.fetchone()
        i += 1

    cursor.close()
    conexion.close()

    auxEquipo = importTable(DatosSueltos[0], year)

    DatosEquipo = []

    for i in range(len(auxEquipo)):
        if (auxEquipo[i][0] == equipo):
            DatosEquipo.append(auxEquipo[i])

    def promedioGol(Datos):
        prom = Datos[0][5]/Datos[0][1]
        return prom

    def diferenciaGol(Datos):
        dif = Datos[0][7]
        return dif

    def puntosGanados(Datos):
        dif = (Datos[0][8]/(Datos[0][1]*3))*100
        return dif

    def posTabla(equipo1):
        cont1 = 0
        for i in range(len(auxEquipo)):
            cont1 = cont1+1
            if (auxEquipo[i][0] == equipo1):
                pos = cont1
        pos=len(auxEquipo)-pos+1
        return pos

    def partidosNoPerdidos(Datos):
        dif = (1-(Datos[0][4]/Datos[0][1]))*100
        return dif

    DatosComparacion = []
    DatosComparacion.append(promedioGol(DatosEquipo))
    DatosComparacion.append(diferenciaGol(DatosEquipo))
    DatosComparacion.append(puntosGanados(DatosEquipo))
    DatosComparacion.append(posTabla(equipo))
    DatosComparacion.append(partidosNoPerdidos(DatosEquipo))

    return DatosComparacion
