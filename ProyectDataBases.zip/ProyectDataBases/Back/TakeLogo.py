from bs4 import BeautifulSoup
import requests
import urllib.request



def LogoDowload(Nombre,Pais):
    url = "https://www.google.com/search?q=Logo+"+Nombre+"+soccer+"+Pais+"+team&tbm=isch&ved=2ahUKEwj8zZvgx4H7AhW-YjABHZmwCtYQ2-cCegQIABAA&oq=Logo+Huracan+soccer+team&gs_lcp=CgNpbWcQDFAAWABg_AloAHAAeACAAW6IAW6SAQMwLjGYAQCqAQtnd3Mtd2l6LWltZ8ABAQ&sclient=img&ei=4BNbY_zdCL7FwbkPmeGqsA0&bih=969&biw=1873&hl=9"
    pagina = requests.get(url)
    soup = BeautifulSoup(pagina.content, "html.parser")
    titulo = soup.find_all("img")
    src=titulo[1]['src']
    return urllib.request.urlretrieve(titulo[1]['src']),src

