const teamsG2 = document.querySelector('#teams');

const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['', '', '', '', '', '', '', '', '', ''],
        datasets: [{
            label: "Average goals",
            data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            backgroundColor: [
                'rgba(255, 99, 132)',
                'rgba(54, 162, 235)',
                'rgba(255, 206, 86)',
                'rgba(75, 192, 192)',
                'rgba(153, 102, 255)',
                'rgba(255, 159, 64)',
                'rgba(255, 206, 86)',
                'rgba(75, 192, 192)',
                'rgba(153, 102, 255)',
                'rgba(255, 159, 64)'
            ],
            borderColor: [
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)',
                'rgba(0, 0, 0, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

function updateG2(tag,data/*,backgroundCol*/,labels) {
    tag.data.datasets[0].data=data;
    tag.data.labels=labels;
    /*tag.data.datasets[0].backgroundColor=backgroundCol;*/
}


///////////////////////////////

function updateImagesG2(tag,urls){
    tag.innerHTML =`<img class="g2img" src=${urls[9]}></img>
    <img src=${urls[8]} class="g2img"></img>
    <img src=${urls[7]} class="g2img"></img>
    <img src=${urls[6]} class="g2img"></img>
    <img src=${urls[5]} class="g2img"></img>
    <img src=${urls[4]} class="g2img"></img>
    <img src=${urls[3]} class="g2img"></img>
    <img src=${urls[2]} class="g2img"></img>
    <img src=${urls[1]} class="g2img"></img>
    <img src=${urls[0]} class="g2img"></img>`;
}

async function RefreshTable(year) {
    try {
        const response = await fetch(`http://127.0.0.1:5000/${year}`, {
            method: 'GET'
        });
        const exam = await response.json();
        return exam;
    } catch (error) {
        console.error(error);
    }
}
async function Table(year) {

    const exam = await RefreshTable(year);
    
    pg=[exam.data[0].pg,exam.data[1].pg,exam.data[2].pg,exam.data[3].pg,exam.data[4].pg,exam.data[5].pg,exam.data[6].pg,exam.data[7].pg,exam.data[8].pg,exam.data[9].pg];
    clubs=[exam.data[0].club,exam.data[1].club,exam.data[2].club,exam.data[3].club,exam.data[4].club,exam.data[5].club,exam.data[6].club,exam.data[7].club,exam.data[8].club,exam.data[9].club];
    imgs=[exam.data[0].img,exam.data[1].img,exam.data[2].img,exam.data[3].img,exam.data[4].img,exam.data[5].img,exam.data[6].img,exam.data[7].img,exam.data[8].img,exam.data[9].img];
    updateG2(myChart,pg.reverse(),clubs.reverse());
    updateImagesG2(teamsG2,imgs)
    myChart.update();
}

Table("2017");


    





