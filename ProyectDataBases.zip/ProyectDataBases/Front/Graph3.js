
const ctx2 = document.getElementById('myChart2').getContext('2d');
const myChart2 = new Chart(ctx2, {
    type: 'radar',
    data: {
        labels: ["Ag", "Gd", "Pw", "Pt", "Pnl"],
        datasets: [ {
            label: 'My First dataset',
            backgroundColor: 'rgba(255, 99, 132,0.5)',
            borderColor: 'rgba(255, 99, 132)',
            borderWidth: 1,
            data: [14, 25, 8, 52, 50],
        },{
            label: 'My First dataset',
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            borderColor: 'rgb(54, 162, 235)',
            borderWidth: 1,
            data: [10, 20, 30, 40, 50],
        }, {
            label: '',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            borderColor: 'rgb(0, 0, 0)',
            borderWidth: 1,
            data: [0, 0, 0, 0, 0],
        }]
    }
});

function updateG3(tag) {
   
 
    /*tag.data.datasets[0].backgroundColor=backgroundCol;*/
}


