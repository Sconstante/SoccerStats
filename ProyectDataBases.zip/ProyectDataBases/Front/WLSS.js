const positionsTable = document.querySelector('#tbodyT');
const boton1L = document.querySelector('#boton1L');
const boton1R = document.querySelector('#boton1R');
const boton2L = document.querySelector('#boton2L');
const boton2R = document.querySelector('#boton2R');
const yearTable = document.querySelector('#yearTable');
const leagueTable = document.querySelector('#leagueTable');


const leagues=['Arg1', 'Arg2', 'Aus1', 'Aus2', 'Aut1', 'Bel1', 'Bra1', 'Bra2', 'Bul1', 'Che1', 'Chi1', 'Chi2', 'Cro1', 'Czh1', 'Den1', 'Den2', 'Eng1', 'Eng2', 'Eng3', 'Eng4', 'Eng5', 'Fin1', 'Fra1', 'Fra2', 'Ger1', 'Ger2', 'Ger3', 'Gre1', 'Hun1', 'Ice1', 'Ire1', 'Ire2', 'Isr1', 'Ita1', 'Ita2', 'Jap1', 'Jap2', 'Kor1', 'Mex1', 'Ned1', 'Ned2', 'Nor1', 'Nor2', 'Pol1', 'Por1', 'Por2', 'Rom1', 'Rus1', 'Sco1', 'Sco2', 'Ser1', 'Slk1', 'Slo1', 'Spa1', 'Spa2', 'Swe1', 'Swe2', 'Swi1', 'Tur1', 'Ukr1', 'USA1', 'Wel1'];
const years=["2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020","2021"]
var currentLeague=45;
var currentYear=15;

yearTable.innerHTML="Season: "+years[currentYear];
async function RefreshTable(league,year) {
    try {
        const response = await fetch(`http://127.0.0.1:5000/${league}/${year}`, {
            method: 'GET'
        });
        const exam = await response.json();
        return exam;
    } catch (error) {
        console.error(error);
    }
}
async function renderTable(league,year) {

    const exam = await RefreshTable(league,year);
    
    positionsTable.innerHTML="";

    for (var i=0;i<exam.data.length;i++){
        addRow(positionsTable,exam.data[i].club,exam.data[i].pj,exam.data[i].g,exam.data[i].e,exam.data[i].p,exam.data[i].gf,exam.data[i].gc,exam.data[i].dg,exam.data[i].Pts,exam.data[i].img);
    }

}

function addRow(tag,club,pj,g,e,p,gf,gc,dg,pts,url) {
    tag.innerHTML =tag.innerHTML+`<tr class="datos"><th class="imagen"> <img class="logo" src=${url}></img></th> <th class="club"> ${club} </th> <th class="otherTable">${pj}</th><th class="otherTable">${g}</th><th class="otherTable">${e}</th><th class="otherTable">${p}</th><th class="otherTable">${gf}</th><th class="otherTable">${gc}</th><th class="otherTable">${dg}</th><th class="otherTable">${pts}</th></tr>`;
}

renderTable(leagues[currentLeague],years[currentYear]);

boton1R.addEventListener('click', (e) => {
    e.preventDefault();
    if(currentYear<16){
        currentYear+=1;
    }
    yearTable.innerHTML="Season: "+years[currentYear];  
    renderTable(leagues[currentLeague],years[currentYear]);
});
boton1L.addEventListener('click', (e) => {
    e.preventDefault();
    if(currentYear>0){
        currentYear-=1;
    }  
    yearTable.innerHTML="Season: "+years[currentYear];  
    renderTable(leagues[currentLeague],years[currentYear]);
});
boton2R.addEventListener('click', (e) => {
    e.preventDefault();
    if(currentLeague<61){
        currentLeague+=1;
    }
    leagueTable.innerHTML="League: "+leagues[currentLeague];  
    renderTable(leagues[currentLeague],years[currentYear]);
});
boton2L.addEventListener('click', (e) => {
    e.preventDefault();
    if(currentLeague>0){
        currentLeague-=1;
    }  
    leagueTable.innerHTML="League: "+leagues[currentLeague];  
    renderTable(leagues[currentLeague],years[currentYear]);
});
////////////////////////////////////////////////










